﻿using HotDeskSystemAPI.Data;
using HotDeskSystemAPI.Interfaces;
using HotDeskSystemAPI.Models;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace HotDeskSystemAPI.Repository
{
    public class AdminDeskRepository : IAdminDeskRepository
    {
        private readonly AppDbContext _context;
        public AdminDeskRepository(AppDbContext context) 
        {
            _context = context;
        }

        public ICollection<Desk> GetDesks()
        {
            return _context.Desks.OrderBy(p => p.Id).ToList();
        }



        public bool DeskExists(string DeskName)
        {
            return _context.Desks.Any(p=>p.Name == DeskName);
        }

        
        public bool UpdateDesk(Desk desk)
        {
            _context.Update(desk);
            return Save();
        }


        public bool CreateDesk(string DeskName, Location location)
        {
            var desk = new Desk
            {
                Name=DeskName,
                Location=location
            };
            location.DeskId = desk.Id;
            _context.Add(desk);
            return Save();
        }

        public bool DeleteDesk(Desk desk)
        {
            _context.Remove(desk);
            return Save();
        }

        public bool Save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }

        public Desk GetDesk(string DeskName)
        {
            return _context.Desks.Where(p => p.Name == DeskName).FirstOrDefault();
        }

        public Desk GetDesk(int DeskId)
        {
            return _context.Desks.Where(p => p.Id == DeskId).FirstOrDefault();
        }
    }
}
