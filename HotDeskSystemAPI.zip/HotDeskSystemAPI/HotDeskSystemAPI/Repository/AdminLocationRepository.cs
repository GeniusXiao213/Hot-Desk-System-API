﻿using HotDeskSystemAPI.Data;
using HotDeskSystemAPI.Interfaces;
using HotDeskSystemAPI.Models;

namespace HotDeskSystemAPI.Repository
{
    public class AdminLocationRepository:IAdminLocationRepository
    {
        private readonly AppDbContext _context;
        public AdminLocationRepository(AppDbContext context)
        {
            _context = context;
        }
        public ICollection<Location> GetLocations()
        {
            return _context.Locations.OrderBy(p => p.Id).ToList();
        }
        public bool CreateLocation(string LocationName)
        {
            var location = new Location
            {
                LocationName = LocationName,
            };
            _context.Add(location);
            return Save();
        }

        public bool DeleteLocation(Location location)
        {
            _context.Remove(location);
            return Save();
        }
        public bool LocationExists(string LocationName)
        {
            return _context.Locations.Any(p => p.LocationName == LocationName);
        }

        public bool UpdateLocation(Location location)
        {
            _context.Update(location);
            return Save();
        }
        public bool Save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }

        public Location GetLocation(string LocationName)
        {
            return _context.Locations.Where(p => p.LocationName == LocationName).FirstOrDefault();
        }

        public Location GetLocationById(int? LocationId)
        {
            return _context.Locations.Where(p => p.Id == LocationId).FirstOrDefault();
        }
    }
}
