﻿using HotDeskSystemAPI.Data;
using HotDeskSystemAPI.Interfaces;
using HotDeskSystemAPI.Models;

namespace HotDeskSystemAPI.Repository
{
    public class EmployeeDeskRepository : IEmployeeDeskRepository
    {
        private readonly AppDbContext _context;
        public EmployeeDeskRepository(AppDbContext context)
        {
            _context = context;
        }

        public ICollection<Desk> GetDesks()
        {
            return _context.Desks.OrderBy(p => p.Id).ToList();
        }
        
        public bool ReserveDesk(string DeskName,int EmployeeId)
        {
            var desk=_context.Desks.Where(p=>p.Name== DeskName).FirstOrDefault();
            var employee=_context.Employees.Where(p=>p.Id==EmployeeId).FirstOrDefault();
            if (employee == null)
            {
                return false;
            }
            if(employee.status==1)
            {
                
                var deskToChange = employee.Desk;
                DateTime deskBookedTime = (DateTime)deskToChange.BookedTIme;
                var timeNow = DateTime.Now;
                //can't change desk if last reservation is more than 24h ago
                if (timeNow.Day - deskBookedTime.Day > 1 || timeNow.Month> deskBookedTime.Month ||timeNow.Year>deskBookedTime.Year)
                {
                    return false;
                }
                deskToChange.IsBooked = 0;
                deskToChange.BookedTIme = null;
                deskToChange.Employee = null;
            }
            desk.IsBooked = 1;
            desk.Employee = employee;
            desk.BookedTIme = DateTime.Now;
            _context.Update(desk);
            employee.status = 1;
            employee.Desk=desk;
            _context.Update(employee);
            return Save();
        }

        public Desk GetDeskByLocation(string locationName)
        {
            var location=_context.Locations.Where(p=>p.LocationName == locationName).FirstOrDefault();
            if(location == null)
            {
                return null;
            }
            int locationId = location.Id;
            return _context.Desks.Where(p=>p.Location == location).FirstOrDefault();
        }

        public bool DeskExists(string DeskName)
        {
            return _context.Desks.Any(p => p.Name == DeskName);
        }

        public bool Save()
        {
            var saved = _context.SaveChanges();
            return saved > 0 ? true : false;
        }

        public Desk GetDesk(string DeskName)
        {
            return _context.Desks.Where(p => p.Name == DeskName).FirstOrDefault();
        }

        public bool UpdateEmployee(Employee employee)
        {
            _context.Update(employee);
            return Save();
        }

        public bool EmployeeExists(int EmployeeId)
        {
            return _context.Employees.Any(p => p.Id == EmployeeId);
        }
    }
}
