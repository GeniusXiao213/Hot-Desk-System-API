﻿using HotDeskSystemAPI.Interfaces;
using HotDeskSystemAPI.Models;
using HotDeskSystemAPI.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotDeskSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AdminDeskController : ControllerBase
    {
        private readonly IAdminDeskRepository _adminDeskRepository;
        private readonly IAdminLocationRepository _adminLocationRepository;

        public AdminDeskController(IAdminDeskRepository adminDeskRepository, IAdminLocationRepository adminLocationRepository)
        {
            _adminDeskRepository = adminDeskRepository;

            _adminLocationRepository = adminLocationRepository;
        }

        //SEE THE LIST OF ALL DESKS
        //administration can get to see from the info in Desk.cs which covers which employee reserves this desk

        [HttpGet("GetDesks")]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Desk>))]
        public IActionResult GetDesks()
        {
            var desks = _adminDeskRepository.GetDesks();
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            return Ok(desks);
        }

        //ADD DESK IN LOCATION

        [HttpPost("CreateDesk")]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        public IActionResult CreateDesk([FromQuery] string DeskName, [FromQuery] string locationName)
        {
            if (DeskName == null || locationName == null)
            {
                return BadRequest(ModelState);
            }
            if (!_adminLocationRepository.LocationExists(locationName))
            {
                ModelState.AddModelError("", "Location does not exist");
                return StatusCode(422, ModelState);
            }
            if (_adminDeskRepository.DeskExists(DeskName))
            {
                ModelState.AddModelError("", "Desk already exists");
                return StatusCode(422, ModelState);
            }

            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var LocationToAddDesk = _adminLocationRepository.GetLocation(locationName);
            if (LocationToAddDesk.Desk != null)
            {
                ModelState.AddModelError("", "Desk exists in this location");
                return StatusCode(422, ModelState);
            }

            if (!_adminDeskRepository.CreateDesk(DeskName, LocationToAddDesk))
            {
                ModelState.AddModelError("", "Something went wrong while saving");
                return StatusCode(500, ModelState);
            }

            return Ok("Successfully created");
        }

        //CHANGE DESK LOCATION, SEEMS ITS NOT NECCESSARY:)

        //[HttpPut]
        //[ProducesResponseType(400)]
        //[ProducesResponseType(204)]
        //[ProducesResponseType(404)]
        //public IActionResult UpdateDeskLocation(string DeskName, string LocationName)
        //{
        //    if(!_adminDeskRepository.DeskExists(DeskName))
        //    {
        //        return NotFound();
        //    }
        //    if(!_adminLocationRepository.LocationExists(LocationName))
        //    {
        //        return BadRequest(ModelState);
        //    }
        //    if(_adminLocationRepository.GetLocation(LocationName).DeskId!=null)
        //    {
        //        ModelState.AddModelError("", "Desk exsits here");
        //        return StatusCode(500, ModelState);
        //    }
        //    if(!ModelState.IsValid) 
        //    {
        //        return BadRequest(ModelState);
        //    }
        //    var DeskToUpdate=_adminDeskRepository.GetDesk(DeskName);
        //    if(!_adminDeskRepository.UpdateDesk(DeskToUpdate))
        //    {
        //        ModelState.AddModelError("", "Something went wrong updating desk");
        //        return StatusCode(500, ModelState);
        //    }
        //    return NoContent();
        //}


        //REMOVE DESK FROM LOCATION IF NO RESERVATION

        [HttpDelete("RemoveDesk")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult RemoveDesk([FromQuery] string DeskName)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (!_adminDeskRepository.DeskExists(DeskName))
            {
                return NotFound();
            }

            var DeskToDelete = _adminDeskRepository.GetDesk(DeskName);

            if (DeskToDelete.IsBooked ==1)
            {
                ModelState.AddModelError("", "This desk is already reserved, can't delete");
                return StatusCode(422, ModelState);
            }

            //update location

            var DeskLocation = DeskToDelete.Location;
            if(DeskLocation != null)
            {
                DeskLocation.DeskId = 0;
                if (_adminLocationRepository.UpdateLocation(DeskLocation))
                {
                    ModelState.AddModelError("", "Something went wrong when deleting desk from location");
                }
            }
            if (!_adminDeskRepository.DeleteDesk(DeskToDelete))
            {
                ModelState.AddModelError("", "Something went wrong when deleting desk");
            }
            return Ok("Successfully remove the desk");
        }

        //MAKE DESK UNAVAILABLE
        //my desgin of this system is that only employees can reserve desk(change status to 1) while admin can
        //only make desks unavailable to use(change status to 2)

        [HttpPut("ChangeDeskStatus")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult ChangeDeskStatus(string DeskName)
        {
            if(!_adminDeskRepository.DeskExists(DeskName))
            {
                return NotFound();
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var DeskToChangeStatus = _adminDeskRepository.GetDesk(DeskName);
            if (DeskToChangeStatus.IsBooked == 1)
            {
                ModelState.AddModelError("", "This desk is already reserved, can't change status");
                return StatusCode(422, ModelState);
            }
            DeskToChangeStatus.IsBooked = 2;
            
            if(!_adminDeskRepository.UpdateDesk(DeskToChangeStatus))
            {
                ModelState.AddModelError("", "Something went wrong when updating desk");
            }
            return Ok("Successfully make desk unavailable");

        }

        //[HttpPut]
        //[ProducesResponseType(400)]
        //[ProducesResponseType(204)]
        //[ProducesResponseType(404)]
        //public IActionResult UpdateLocation([FromQuery] string locationName, [FromQuery] string DeskName)
        //{
        //    if (!_adminLocationRepository.LocationExists(locationName) || !ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }
        //    if (!_adminDeskRepository.DeskExists(DeskName))
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    var LocationToUpdate = _adminLocationRepository.GetLocation(locationName);
        //    if (LocationToUpdate.DeskId != null)
        //    {
        //        ModelState.AddModelError("", "Desk exists in this location");
        //        return StatusCode(422, ModelState);
        //    }
        //    var desk = _adminDeskRepository.GetDesk(locationName);
        //    LocationToUpdate.DeskId = desk.Id;
        //    LocationToUpdate.Desk = desk;
        //    if (!_adminLocationRepository.UpdateLocation(LocationToUpdate))
        //    {
        //        ModelState.AddModelError("", "Something went wrong updating location");
        //        return StatusCode(500, ModelState);
        //    }
        //    return NoContent();
        //}   


    }
}
