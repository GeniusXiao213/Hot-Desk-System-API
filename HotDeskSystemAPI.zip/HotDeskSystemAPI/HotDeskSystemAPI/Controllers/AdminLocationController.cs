﻿using HotDeskSystemAPI.Interfaces;
using HotDeskSystemAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotDeskSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AdminLocationController : ControllerBase
    {
        private readonly IAdminDeskRepository _adminDeskRepository;
        private readonly IAdminLocationRepository _adminLocationRepository;

        public AdminLocationController(IAdminDeskRepository adminDeskRepository, IAdminLocationRepository adminLocationRepository)
        {
            _adminDeskRepository = adminDeskRepository;

            _adminLocationRepository = adminLocationRepository;
        }

        //GET THE LIST OF ALL LOCATIONS

        [HttpGet("GetLocations")]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Location>))]
        public IActionResult GetLocations()
        {
            var locations = _adminLocationRepository.GetLocations();
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            return Ok(locations);
        }

        //ADD LOCATION

        [HttpPost("CreateLocation")]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        public IActionResult CreateLocation([FromQuery] string locationName)
        {
            if(locationName == null)
            {
                return BadRequest(ModelState);
            }
            if(_adminLocationRepository.LocationExists(locationName))
            {
                ModelState.AddModelError("", "Location already exists");
                return StatusCode(422, ModelState);
            }
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            if (!_adminLocationRepository.CreateLocation(locationName))
            {
                ModelState.AddModelError("", "Something went wrong while saving");
                return StatusCode(500, ModelState);
            }

            return Ok("Successfully created");
        }
        
        //REMOVE LOCATION IF NO DESK EXISTS HERE

        [HttpDelete("RemoveLocation")]
        [ProducesResponseType(400)]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public IActionResult RemoveLocation([FromQuery] string locationName)
        {
            if (!_adminLocationRepository.LocationExists(locationName))
            {
                return NotFound();
            }
            var LocationToDelete = _adminLocationRepository.GetLocation(locationName);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            if (LocationToDelete.Desk != null)
            {
                ModelState.AddModelError("", "Desk exsists in this location, can't delete");
                return StatusCode(422, ModelState);
            }
            if (!_adminLocationRepository.DeleteLocation(LocationToDelete))
            {
                ModelState.AddModelError("", "Something went wrong when deleting location");
            }
            return Ok("Successfully remove the location");
        }
    }
}
