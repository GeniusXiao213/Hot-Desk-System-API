﻿using HotDeskSystemAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace HotDeskSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        public static string adminPassword = "HahaIAmTheAdminPassword!";
        private readonly IConfiguration _configuration;

        public AuthController(IConfiguration configuration)
        {
            _configuration= configuration;
        }

        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login([FromQuery]string Password)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if(Password != adminPassword)
            {
                ModelState.AddModelError("", "Password not correct!");
                return StatusCode(422, ModelState);
            }
            var authSigninKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_configuration["JWT:Secret"]));

            var token = new JwtSecurityToken(
                issuer: _configuration["JWT:ValidIssuer"],
                audience: _configuration["JWT:ValidAudience"],
                expires: DateTime.Now.AddDays(1),
                signingCredentials: new SigningCredentials(authSigninKey, SecurityAlgorithms.HmacSha256Signature)
                );

            return Ok(new JwtSecurityTokenHandler().WriteToken(token));
        }
    }
}
