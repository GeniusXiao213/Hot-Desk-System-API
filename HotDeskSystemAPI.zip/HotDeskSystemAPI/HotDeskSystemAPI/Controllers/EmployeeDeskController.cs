﻿using AutoMapper;
using HotDeskSystemAPI.Dto;
using HotDeskSystemAPI.Interfaces;
using HotDeskSystemAPI.Models;
using HotDeskSystemAPI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotDeskSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeDeskController : ControllerBase
    {
        private readonly IEmployeeDeskRepository _employeeDeskRepository;
        private readonly IMapper _mapper;
        public EmployeeDeskController(IEmployeeDeskRepository employeeDeskRepository,IMapper mapper)
        {
            _employeeDeskRepository= employeeDeskRepository;
            _mapper = mapper;
        }

        //Get the list of desks
        //dertemine which desks are available to book
        //map over with DeskDto.cs makes employees can not see which user specifically reserves which desk

        [HttpGet("GetDesks")]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Desk>))]
        public IActionResult GetDesks()
        {
            var desks = _mapper.Map<List<DeskDto>>(_employeeDeskRepository.GetDesks());
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            return Ok(desks);
        }

        //filter desk based on location

        [HttpGet("GetDesk")]
        [ProducesResponseType(200, Type = typeof(DeskDto))]
        [ProducesResponseType(400)]
        public IActionResult GetDesk([FromQuery] string locationName)
        {
            DeskDto desk = _mapper.Map<DeskDto>(_employeeDeskRepository.GetDeskByLocation(locationName));
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if(desk == null)
            {
                ModelState.AddModelError("", "Location not exists");
                return StatusCode(422, ModelState);
            }
            return Ok(desk);
        }

        //reserve desk or change desk

        [HttpPut("BookDesk")]
        public IActionResult BookDesk([FromQuery] string DeskName, [FromQuery]  int EmployeeId)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if(!_employeeDeskRepository.EmployeeExists(EmployeeId))
            {
                ModelState.AddModelError("", "Employee not exists");
                return StatusCode(422, ModelState);
            }
            
            if(!_employeeDeskRepository.DeskExists(DeskName))
            {
                ModelState.AddModelError("", "Desk not exists");
                return StatusCode(422, ModelState);
            }
            var timeNow=DateTime.Now;
            

            if (_employeeDeskRepository.GetDesk(DeskName).IsBooked!=0)
            {
                DateTime bookedTime = (DateTime)_employeeDeskRepository.GetDesk(DeskName).BookedTIme;
                if (timeNow.Day - bookedTime.Day > 7 || timeNow.Month > bookedTime.Month || timeNow.Year > bookedTime.Year)
                {
                    var prevEmployee = _employeeDeskRepository.GetDesk(DeskName).Employee;
                    prevEmployee.DeskId = 0;
                    if(!_employeeDeskRepository.UpdateEmployee(prevEmployee) || !_employeeDeskRepository.ReserveDesk(DeskName, EmployeeId))
                    {
                        ModelState.AddModelError("", "Something went wrong while booking desk");
                        return StatusCode(500, ModelState);
                    }
                    return Ok("successfully booked the desk");

                }
                ModelState.AddModelError("", "Desk is already booked");
                return StatusCode(422, ModelState);
            }
            if (!_employeeDeskRepository.ReserveDesk(DeskName,EmployeeId))
            {
                ModelState.AddModelError("", "Something went wrong while booking desk");
                return StatusCode(500, ModelState);
            }
            return Ok("successfully booked the desk");

        }
    }
}
