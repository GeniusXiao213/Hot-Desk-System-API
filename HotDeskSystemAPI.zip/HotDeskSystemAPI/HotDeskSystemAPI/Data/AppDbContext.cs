﻿using HotDeskSystemAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace HotDeskSystemAPI.Data
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions option):base(option)
        {

        }
        public DbSet<Desk> Desks { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Location> Locations { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //all the relation between database tables are one to one in this case

            modelBuilder.Entity<Desk>()
                .HasOne(x => x.Location)
                .WithOne(x => x.Desk)
                .HasForeignKey<Location>(fk => fk.DeskId);

            modelBuilder.Entity<Desk>()
                .HasOne(x => x.Employee)
                .WithOne(x => x.Desk)
                .HasForeignKey<Employee>(fk => fk.DeskId);

            //modelBuilder.Entity<Employee>()
            //    .HasOne(x => x.Desk)
            //    .WithOne(x => x.Employee)
            //    .HasForeignKey<Employee>(fk => fk.DeskId);

            //modelBuilder.Entity<Location>()
            //    .HasOne(x => x.Desk)
            //    .WithOne(x => x.Location)
            //    .HasForeignKey<Location>(fk => fk.DeskId);
        }
    }
}
