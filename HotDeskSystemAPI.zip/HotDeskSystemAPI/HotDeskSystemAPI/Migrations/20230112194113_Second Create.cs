﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HotDeskSystemAPI.Migrations
{
    /// <inheritdoc />
    public partial class SecondCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Desks_Locations_LocationId",
                table: "Desks");

            migrationBuilder.DropIndex(
                name: "IX_Desks_LocationId",
                table: "Desks");

            migrationBuilder.RenameColumn(
                name: "BookedDeskId",
                table: "Employees",
                newName: "status");

            migrationBuilder.AlterColumn<int>(
                name: "LocationId",
                table: "Desks",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "EmployeeId",
                table: "Desks",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "Name",
                table: "Desks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_Desks_EmployeeId",
                table: "Desks",
                column: "EmployeeId",
                unique: true,
                filter: "[EmployeeId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Desks_LocationId",
                table: "Desks",
                column: "LocationId",
                unique: true,
                filter: "[LocationId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_Desks_Employees_EmployeeId",
                table: "Desks",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Desks_Locations_LocationId",
                table: "Desks",
                column: "LocationId",
                principalTable: "Locations",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Desks_Employees_EmployeeId",
                table: "Desks");

            migrationBuilder.DropForeignKey(
                name: "FK_Desks_Locations_LocationId",
                table: "Desks");

            migrationBuilder.DropIndex(
                name: "IX_Desks_EmployeeId",
                table: "Desks");

            migrationBuilder.DropIndex(
                name: "IX_Desks_LocationId",
                table: "Desks");

            migrationBuilder.DropColumn(
                name: "Name",
                table: "Desks");

            migrationBuilder.RenameColumn(
                name: "status",
                table: "Employees",
                newName: "BookedDeskId");

            migrationBuilder.AlterColumn<int>(
                name: "LocationId",
                table: "Desks",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "EmployeeId",
                table: "Desks",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Desks_LocationId",
                table: "Desks",
                column: "LocationId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Desks_Locations_LocationId",
                table: "Desks",
                column: "LocationId",
                principalTable: "Locations",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
