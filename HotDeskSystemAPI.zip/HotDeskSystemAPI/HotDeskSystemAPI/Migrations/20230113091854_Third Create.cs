﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HotDeskSystemAPI.Migrations
{
    /// <inheritdoc />
    public partial class ThirdCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Desks_Employees_EmployeeId",
                table: "Desks");

            migrationBuilder.DropForeignKey(
                name: "FK_Desks_Locations_LocationId",
                table: "Desks");

            migrationBuilder.DropIndex(
                name: "IX_Desks_EmployeeId",
                table: "Desks");

            migrationBuilder.DropIndex(
                name: "IX_Desks_LocationId",
                table: "Desks");

            migrationBuilder.AddColumn<int>(
                name: "DeskId",
                table: "Locations",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "DeskId",
                table: "Employees",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "BookedTIme",
                table: "Desks",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.CreateIndex(
                name: "IX_Locations_DeskId",
                table: "Locations",
                column: "DeskId",
                unique: true,
                filter: "[DeskId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Employees_DeskId",
                table: "Employees",
                column: "DeskId",
                unique: true,
                filter: "[DeskId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_Employees_Desks_DeskId",
                table: "Employees",
                column: "DeskId",
                principalTable: "Desks",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Locations_Desks_DeskId",
                table: "Locations",
                column: "DeskId",
                principalTable: "Desks",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Employees_Desks_DeskId",
                table: "Employees");

            migrationBuilder.DropForeignKey(
                name: "FK_Locations_Desks_DeskId",
                table: "Locations");

            migrationBuilder.DropIndex(
                name: "IX_Locations_DeskId",
                table: "Locations");

            migrationBuilder.DropIndex(
                name: "IX_Employees_DeskId",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "DeskId",
                table: "Locations");

            migrationBuilder.DropColumn(
                name: "DeskId",
                table: "Employees");

            migrationBuilder.AlterColumn<DateTime>(
                name: "BookedTIme",
                table: "Desks",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Desks_EmployeeId",
                table: "Desks",
                column: "EmployeeId",
                unique: true,
                filter: "[EmployeeId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Desks_LocationId",
                table: "Desks",
                column: "LocationId",
                unique: true,
                filter: "[LocationId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_Desks_Employees_EmployeeId",
                table: "Desks",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Desks_Locations_LocationId",
                table: "Desks",
                column: "LocationId",
                principalTable: "Locations",
                principalColumn: "Id");
        }
    }
}
