﻿namespace HotDeskSystemAPI.Models
{
    public class Location
    {
        public int Id { get; set; }
        public string LocationName { get; set; }=string.Empty;
        public int? DeskId { get; set; }
        public Desk? Desk { get; set; }
    }
}
