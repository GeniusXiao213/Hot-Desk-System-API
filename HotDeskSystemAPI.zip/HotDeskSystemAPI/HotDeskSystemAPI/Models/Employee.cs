﻿using System.ComponentModel.DataAnnotations;

namespace HotDeskSystemAPI.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }=string.Empty;
        public string Password { get; set; }= string.Empty;
        public int status { get; set; } = 0;
        //0 means this employee hasn't booked a desk yet, 1 means already booked, hence he/she cant book another one

        public int? DeskId { get; set; }
        public Desk? Desk { get; set; }


    }
}
