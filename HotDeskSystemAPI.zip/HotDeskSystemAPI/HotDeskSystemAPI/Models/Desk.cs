﻿using System.ComponentModel.DataAnnotations;

namespace HotDeskSystemAPI.Models
{
    public class Desk
    {
        
        public int Id { get; set; }

        public string Name { get; set; }=string.Empty;
        public int IsBooked { get; set; } = 0;
        //0 means this desk is not booked yet, 1 means already booked, 2 means admin makes this desk unavailable
        public DateTime? BookedTIme { get; set; }

        //public int? LocationId { get; set; }
        public Location? Location { get; set; }

        //public int? EmployeeId { get; set; }
        public Employee? Employee { get; set; }
    }
}
