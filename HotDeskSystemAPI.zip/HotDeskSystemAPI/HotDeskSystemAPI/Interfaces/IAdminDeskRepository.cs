﻿using HotDeskSystemAPI.Models;

namespace HotDeskSystemAPI.Interfaces
{
    public interface IAdminDeskRepository
    {
        ICollection<Desk> GetDesks();

        Desk GetDesk(string DeskName);
        Desk GetDesk(int DeskId);
        bool DeskExists(string DeskName);
        bool UpdateDesk(Desk desk);

        bool CreateDesk(string DeskName, Location location);
        bool DeleteDesk(Desk desk);
        bool Save();

    }
}
