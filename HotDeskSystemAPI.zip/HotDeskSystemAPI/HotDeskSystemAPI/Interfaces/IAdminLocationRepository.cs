﻿using HotDeskSystemAPI.Models;

namespace HotDeskSystemAPI.Interfaces
{
    public interface IAdminLocationRepository
    {
        ICollection<Location> GetLocations();
        Location GetLocation(string LocationName);
        Location GetLocationById(int? LocationId);
        bool LocationExists(string LocationName);
        bool UpdateLocation(Location location);
        bool CreateLocation(string LocationName);
        bool DeleteLocation(Location location);
        bool Save();
    }
}
