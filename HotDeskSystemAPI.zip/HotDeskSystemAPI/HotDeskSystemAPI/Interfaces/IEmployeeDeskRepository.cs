﻿using HotDeskSystemAPI.Models;

namespace HotDeskSystemAPI.Interfaces
{
    public interface IEmployeeDeskRepository
    {
        ICollection<Desk> GetDesks();
        Desk GetDesk(string DeskName);
        Desk GetDeskByLocation(string locationName);
        bool ReserveDesk(string DeskName,int EmployeeId);
        bool UpdateEmployee(Employee employee);
        bool DeskExists(string DeskName);
        bool EmployeeExists(int EmployeeId);
        bool Save();
    }
}
