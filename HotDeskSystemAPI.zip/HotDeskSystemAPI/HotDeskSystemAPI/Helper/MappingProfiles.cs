﻿using AutoMapper;
using HotDeskSystemAPI.Dto;
using HotDeskSystemAPI.Models;

namespace HotDeskSystemAPI.Helper
{
    public class MappingProfiles:Profile
    {
        public MappingProfiles()
        {
            CreateMap<Desk, DeskDto>();
        }
    }
}
