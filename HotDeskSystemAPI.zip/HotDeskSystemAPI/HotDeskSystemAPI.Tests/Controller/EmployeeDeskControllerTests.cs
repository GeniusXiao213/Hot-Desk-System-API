﻿using AutoMapper;
using FakeItEasy;
using FluentAssertions;
using HotDeskSystemAPI.Controllers;
using HotDeskSystemAPI.Dto;
using HotDeskSystemAPI.Interfaces;
using HotDeskSystemAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotDeskSystemAPI.Tests.Controller
{
    
    public class EmployeeDeskControllerTests
    {
        private readonly IEmployeeDeskRepository _employeeDeskRepository;
        private readonly IMapper _mapper;
        public EmployeeDeskControllerTests()
        {
            _employeeDeskRepository = A.Fake<IEmployeeDeskRepository>();
            _mapper = A.Fake<IMapper>();
        }

        [Fact]
        public void EmployeeDeskController_GetDesks_ReturnOK()
        {
            //Arrange
            var desks = A.Fake<ICollection<DeskDto>>();
            var deskList=A.Fake<List<DeskDto>>();
            A.CallTo(()=>_mapper.Map<List<DeskDto>>(desks)).Returns(deskList);
            var controller=new EmployeeDeskController(_employeeDeskRepository, _mapper);

            //Act
            var result = controller.GetDesks();

            //Assert
            result.Should().NotBeNull();
            result.Should().BeOfType(typeof(OkObjectResult));
        }

        [Theory]
        [InlineData("location")]
        public void EmployeeDeskController_GetDesk_ReturnOK(string location)
        {
            //Arrange
            var desk=A.Fake<DeskDto>();
            A.CallTo(()=>_mapper.Map<DeskDto>(desk)).Returns(desk);
            var controller = new EmployeeDeskController(_employeeDeskRepository, _mapper);

            //Act
            var result = controller.GetDesk(location);

            //Assert
            result.Should().NotBeNull();
            result.Should().BeOfType(typeof(OkObjectResult));
        }

        [Fact]
        public void EmployeeDeskController_BookDesk_ReturnOK()
        {
            //Arrange
            var desk = A.Fake<DeskDto>();
            desk.IsBooked = 0;
            int EmployeeId = 1;
            A.CallTo(()=> _employeeDeskRepository.EmployeeExists(EmployeeId)).Returns(true);
            A.CallTo(() => _employeeDeskRepository.DeskExists(desk.Name)).Returns(true);
            A.CallTo(()=> _employeeDeskRepository.ReserveDesk(desk.Name, EmployeeId)).Returns(true);
            var controller = new EmployeeDeskController(_employeeDeskRepository, _mapper);

            //Act
            var result = controller.BookDesk(desk.Name,EmployeeId);
            //Assert

            
            result.Should().BeOfType(typeof(OkObjectResult));
        }
    }
}
